module.exports = {
  apps: [
    {
      name: 'trader-backend',
      script: 'server/index.ts',
      interpreter: './node_modules/.bin/tsx',
      exec_mode: 'fork',
      instances: 1,
      watch: false,
      time: true,
      env: {
        NODE_ENV: 'production',
        PORT: '8789'
      }
    }
  ]
}


