# P&L report (today, profile=both)

Generated: 2025-09-22T13:46:25.580Z

Time window (local): 9/22/2025, 2:00:00 AM — 9/22/2025, 3:46:23 PM

## Summary by profile

- Aggressive: P&L 0.00 USDT | Sessions 0 | Win rate 0.0%
- Conservative: P&L 0.00 USDT | Sessions 0 | Win rate 0.0%
- Unknown: P&L 0.00 USDT | Sessions 1 | Win rate 0.0%

## Per-symbol breakdown (sum of sessions)

| Symbol | Sessions | Total P&L | Conservative (n/P&L) | Aggressive (n/P&L) | Unknown (n/P&L) |
|---|---:|---:|---:|---:|---:|
| COOKIEUSDT | 1 | 0.0000 | 0/0.00 | 0/0.00 | 1/0.00 |

## Sessions

| Symbol | Entry time | Close time | Profile | Session P&L | buyQty/sellQty | clientOrderId |
|---|---|---|---|---:|---:|---|
| COOKIEUSDT | 9/22/2025, 2:00:15 AM | 9/22/2025, 2:12:15 AM | unknown | 0.0000 | 2235.000000/2235.000000 |  |

Notes: profile determined from first entry clientOrderId prefix; P&L sums Binance REALIZED_PNL in session window.